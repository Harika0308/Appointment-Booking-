// Appointment Booking System shared script

const localStorageKeys = {
  appointments: 'appointments',
  users: 'appUsers',
  registerFormDraft: 'registerFormDraft',
  loginFormDraft: 'loginFormDraft',
  bookingFormDraft: 'bookingFormDraft',
};

const dom = {
  navToggle: document.querySelector('.nav-toggle'),
  navLinks: document.querySelector('.nav-links'),
  registerForm: document.getElementById('registerForm'),
  loginForm: document.getElementById('loginForm'),
  bookingForm: document.getElementById('bookingForm'),
  appointmentSearch: document.getElementById('appointmentSearch'),
  appointmentTableBody: document.querySelector('.appointments-table tbody'),
};

/**
 * Utility helpers
 */
function isValidEmail(value) {
  return /^\S+@\S+\.\S+$/.test(value.trim());
}

function isValidPhone(value) {
  return /^[0-9+\-\s()]{7,20}$/.test(value.trim());
}

function isFutureOrToday(dateValue) {
  if (!dateValue) return false;
  const selectedDate = new Date(dateValue);
  const today = new Date();
  selectedDate.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  return selectedDate >= today;
}

function getStoredData(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (error) {
    return [];
  }
}

function setStoredData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function createAlert(message, type = 'success', container = document.body) {
  clearAlerts(container);
  const alert = document.createElement('div');
  alert.className = `alert-box alert-${type}`;
  alert.textContent = message;
  alert.style.cssText = `
    position: relative;
    padding: 1rem 1.25rem;
    border-radius: 14px;
    margin-bottom: 1rem;
    color: ${type === 'error' ? '#b91c1c' : '#0f172a'};
    background: ${type === 'error' ? 'rgba(254, 226, 226, 0.92)' : 'rgba(219, 234, 254, 0.95)'};
    border: 1px solid ${type === 'error' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(37, 99, 235, 0.22)'};
  `;

  container.prepend(alert);
  window.setTimeout(() => {
    if (alert.parentElement) {
      alert.remove();
    }
  }, 5000);
}

function clearAlerts(container = document.body) {
  container.querySelectorAll('.alert-box').forEach((alert) => alert.remove());
}

function setFieldError(field, message) {
  if (!field) return;
  const errorField = field.closest('.form-group')?.querySelector('.form-error') || document.getElementById(`${field.id}Error`);
  if (errorField) {
    errorField.textContent = message;
  }
}

function clearFormErrors(form) {
  if (!form) return;
  form.querySelectorAll('.form-error').forEach((error) => {
    error.textContent = '';
  });
}

function generateAppointmentId() {
  return `APT-${String(Date.now()).slice(-6)}`;
}

function getUsers() {
  return getStoredData(localStorageKeys.users);
}

function saveUsers(users) {
  setStoredData(localStorageKeys.users, users);
}

function getAppointments() {
  return getStoredData(localStorageKeys.appointments);
}

function saveAppointments(appointments) {
  setStoredData(localStorageKeys.appointments, appointments);
}

/**
 * Form draft utilities for auto-saving form data
 */
function saveFormDraft(formId, formData) {
  setStoredData(formId, formData);
}

function getFormDraft(formId) {
  return getStoredData(formId) || {};
}

function clearFormDraft(formId) {
  localStorage.removeItem(formId);
}

function autoSaveForm(form, storageKey) {
  if (!form) return;
  
  form.addEventListener('input', () => {
    const formData = {};
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach((input) => {
      if (input.name) {
        formData[input.name] = input.value;
      }
    });
    
    saveFormDraft(storageKey, formData);
  });
}

function restoreFormDraft(form, storageKey) {
  if (!form) return;
  
  const draft = getFormDraft(storageKey);
  if (!Object.keys(draft).length) return;
  
  const inputs = form.querySelectorAll('input, textarea, select');
  inputs.forEach((input) => {
    if (input.name && draft[input.name] !== undefined) {
      input.value = draft[input.name];
    }
  });
}

/**
 * Navigation toggle for mobile screens.
 */
if (dom.navToggle && dom.navLinks) {
  dom.navToggle.addEventListener('click', () => {
    dom.navLinks.classList.toggle('show');
  });
}

/**
 * Registration page validation and localStorage user support.
 */
if (dom.registerForm) {
  // Restore form draft on page load
  restoreFormDraft(dom.registerForm, localStorageKeys.registerFormDraft);
  
  // Auto-save form as user types
  autoSaveForm(dom.registerForm, localStorageKeys.registerFormDraft);
  
  dom.registerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    clearAlerts(dom.registerForm);
    clearFormErrors(dom.registerForm);

    const fullName = dom.registerForm.fullName?.value.trim() || '';
    const email = dom.registerForm.email?.value.trim() || '';
    const phone = dom.registerForm.phone?.value.trim() || '';
    const password = dom.registerForm.password?.value || '';
    const confirmPassword = dom.registerForm.confirmPassword?.value || '';

    let isValid = true;

    if (fullName.length < 2) {
      setFieldError(dom.registerForm.fullName, 'Please enter your full name.');
      isValid = false;
    }

    if (!isValidEmail(email)) {
      setFieldError(dom.registerForm.email, 'Please enter a valid email address.');
      isValid = false;
    }

    if (!isValidPhone(phone)) {
      setFieldError(dom.registerForm.phone, 'Please enter a valid phone number.');
      isValid = false;
    }

    if (password.length < 8) {
      setFieldError(dom.registerForm.password, 'Password must be at least 8 characters.');
      isValid = false;
    }

    if (confirmPassword !== password) {
      setFieldError(dom.registerForm.confirmPassword, 'Passwords do not match.');
      isValid = false;
    }

    if (!isValid) {
      createAlert('Please fix the highlighted fields before submitting.', 'error', dom.registerForm);
      return;
    }

    const users = getUsers();
    const normalizedEmail = email.toLowerCase();
    const existingUser = users.find((user) => user.email.toLowerCase() === normalizedEmail);

    if (existingUser) {
      createAlert('An account with this email already exists. Please use a different email.', 'error', dom.registerForm);
      return;
    }

    users.push({ fullName, email: normalizedEmail, phone, password });
    saveUsers(users);

    createAlert('Registration successful! Redirecting to login...', 'success', dom.registerForm);
    dom.registerForm.reset();
    clearFormDraft(localStorageKeys.registerFormDraft);

    window.setTimeout(() => {
      window.location.href = 'login.html';
    }, 1200);
  });
}

/**
 * Login page validation and user check.
 */
if (dom.loginForm) {
  // Restore form draft on page load
  restoreFormDraft(dom.loginForm, localStorageKeys.loginFormDraft);
  
  // Auto-save form as user types
  autoSaveForm(dom.loginForm, localStorageKeys.loginFormDraft);
  
  dom.loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    clearAlerts(dom.loginForm);

    const email = dom.loginForm.email?.value.trim() || '';
    const password = dom.loginForm.password?.value || '';

    let isValid = true;

    if (!isValidEmail(email)) {
      isValid = false;
    }

    if (password.length < 1) {
      isValid = false;
    }

    if (!isValid) {
      createAlert('Please enter a valid email and password.', 'error', dom.loginForm);
      return;
    }

    const users = getUsers();
    const normalizedEmail = email.toLowerCase();
    const user = users.find((entry) => entry.email.toLowerCase() === normalizedEmail);

    if (!user) {
      createAlert('No registered account found for that email. Please register first.', 'error', dom.loginForm);
      return;
    }

    if (user.password !== password) {
      createAlert('Invalid password. Please check your credentials and try again.', 'error', dom.loginForm);
      return;
    }

    createAlert(`Welcome back, ${user.fullName}! Redirecting to your dashboard...`, 'success', dom.loginForm);
    dom.loginForm.reset();
    clearFormDraft(localStorageKeys.loginFormDraft);

    window.setTimeout(() => {
      window.location.href = 'dashboard.html';
    }, 1200);
  });
}

/**
 * Appointment booking form validation and localStorage support.
 */
if (dom.bookingForm) {
  // Restore form draft on page load
  restoreFormDraft(dom.bookingForm, localStorageKeys.bookingFormDraft);
  
  // Auto-save form as user types
  autoSaveForm(dom.bookingForm, localStorageKeys.bookingFormDraft);
  
  dom.bookingForm.addEventListener('submit', (event) => {
    event.preventDefault();
    clearAlerts(dom.bookingForm);
    clearFormErrors(dom.bookingForm);

    const customerName = dom.bookingForm.bookedBy?.value.trim() || '';
    const emailField = dom.bookingForm.email;
    const email = emailField?.value.trim() || '';
    const phone = dom.bookingForm.contactNumber?.value.trim() || '';
    const service = dom.bookingForm.service?.value || '';
    const specialist = dom.bookingForm.doctor?.value || '';
    const appointmentDate = dom.bookingForm.appointmentDate?.value || '';
    const appointmentTime = dom.bookingForm.appointmentTime?.value || '';
    const reason = dom.bookingForm.reason?.value.trim() || '';

    let isValid = true;

    if (!customerName) {
      setFieldError(dom.bookingForm.bookedBy, 'Please enter the customer name.');
      isValid = false;
    }

    if (emailField && (!email || !isValidEmail(email))) {
      setFieldError(emailField, 'Please enter a valid email address.');
      isValid = false;
    }

    if (!isValidPhone(phone)) {
      setFieldError(dom.bookingForm.contactNumber, 'Please enter a valid contact number.');
      isValid = false;
    }

    if (!service) {
      setFieldError(dom.bookingForm.service, 'Please select a service.');
      isValid = false;
    }

    if (!specialist) {
      setFieldError(dom.bookingForm.doctor, 'Please select a specialist.');
      isValid = false;
    }

    if (!isFutureOrToday(appointmentDate)) {
      setFieldError(dom.bookingForm.appointmentDate, 'Please choose a valid appointment date.');
      isValid = false;
    }

    if (!appointmentTime) {
      setFieldError(dom.bookingForm.appointmentTime, 'Please choose an appointment time.');
      isValid = false;
    }

    if (reason.length < 10) {
      setFieldError(dom.bookingForm.reason, 'Please provide a short reason for your visit.');
      isValid = false;
    }

    if (!isValid) {
      createAlert('Please complete the booking form correctly before submitting.', 'error', dom.bookingForm);
      return;
    }

    const appointments = getAppointments();
    const appointment = {
      id: generateAppointmentId(),
      customerName,
      email,
      phone,
      service,
      specialist,
      date: appointmentDate,
      time: appointmentTime,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };

    appointments.unshift(appointment);
    saveAppointments(appointments);

    createAlert('Appointment saved successfully. Redirecting to appointments...', 'success', dom.bookingForm);
    dom.bookingForm.reset();
    clearFormDraft(localStorageKeys.bookingFormDraft);
    window.setTimeout(() => {
      window.location.href = 'appointment.html';
    }, 600);
  });
}

  // Dynamic specialist population based on selected service
  // Keeps previous functionality intact and only updates the #doctor select options.
  (() => {
    const specialistsByService = {
      doctor: [
        { value: 'dr-rajesh-kumar', label: 'Dr. Rajesh Kumar' },
        { value: 'dr-priya-sharma', label: 'Dr. Priya Sharma' },
        { value: 'dr-anil-reddy', label: 'Dr. Anil Reddy' },
      ],
      salon: [
        { value: 'priya-hair-stylist', label: 'Priya Hair Stylist' },
        { value: 'neha-makeup-artist', label: 'Neha Makeup Artist' },
        { value: 'kavya-beautician', label: 'Kavya Beautician' },
        { value: 'rahul-hair-expert', label: 'Rahul Hair Expert' },
      ],
      business: [
        { value: 'arjun-business-consultant', label: 'Arjun Business Consultant' },
        { value: 'sneha-hr-manager', label: 'Sneha HR Manager' },
        { value: 'kiran-business-advisor', label: 'Kiran Business Advisor' },
      ],
      fitness: [
        { value: 'rakesh-fitness-coach', label: 'Rakesh Fitness Coach' },
        { value: 'vikram-gym-trainer', label: 'Vikram Gym Trainer' },
        { value: 'pooja-yoga-trainer', label: 'Pooja Yoga Trainer' },
      ],
      legal: [
        { value: 'adv-ramesh', label: 'Adv. Ramesh' },
        { value: 'adv-suman', label: 'Adv. Suman' },
        { value: 'adv-karthik', label: 'Adv. Karthik' },
      ],
    };

    function getDoctorSelect() {
      return document.getElementById('doctor') || (dom.bookingForm && dom.bookingForm.doctor);
    }

    function clearAndSetDefault(selectEl) {
      selectEl.innerHTML = '';
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Select Specialist';
      selectEl.appendChild(opt);
    }

    function populateSpecialistsFor(serviceKey) {
      const doctorSelect = getDoctorSelect();
      if (!doctorSelect) return;
      clearAndSetDefault(doctorSelect);

      const list = specialistsByService[serviceKey];
      if (!Array.isArray(list)) return;

      list.forEach((spec) => {
        const o = document.createElement('option');
        o.value = spec.value;
        o.textContent = spec.label;
        doctorSelect.appendChild(o);
      });
    }

    const serviceSelect = document.getElementById('service') || (dom.bookingForm && dom.bookingForm.service);
    if (serviceSelect) {
      serviceSelect.addEventListener('change', (e) => {
        const serviceKey = e.target.value;
        populateSpecialistsFor(serviceKey);
      });

      // Initialize specialists on load in case a service is pre-selected
      populateSpecialistsFor(serviceSelect.value);
    }
  })();

/**
 * Search filter for appointment table rows.
 */
function filterAppointmentRows(query) {
  if (!dom.appointmentTableBody) return;
  const searchValue = query.trim().toLowerCase();

  dom.appointmentTableBody.querySelectorAll('tr').forEach((row) => {
    const rowText = row.textContent.toLowerCase();
    row.style.display = rowText.includes(searchValue) ? '' : 'none';
  });
}

if (dom.appointmentSearch) {
  dom.appointmentSearch.addEventListener('input', (event) => {
    filterAppointmentRows(event.target.value);
  });
}

/**
 * Render stored appointments on the appointments page if any exist.
 */
function renderStoredAppointments() {
  if (!dom.appointmentTableBody) return;

  const storedAppointments = getAppointments();
  if (!storedAppointments.length) return;

  const sortedAppointments = storedAppointments.slice().sort((a, b) => {
    const aTime = new Date(a.createdAt).getTime() || 0;
    const bTime = new Date(b.createdAt).getTime() || 0;
    return bTime - aTime;
  });

  dom.appointmentTableBody.innerHTML = '';

  sortedAppointments.forEach((appointment) => {
    const row = document.createElement('tr');
    const statusClass = appointment.status.toLowerCase();
    const specialistName = appointment.specialist || appointment.doctor || '';
    row.innerHTML = `
      <td>${appointment.id}</td>
      <td>${appointment.customerName}</td>
      <td>${appointment.email}</td>
      <td>${appointment.phone}</td>
      <td>${appointment.service.replace(/(^|\s)\S/g, (match) => match.toUpperCase())}</td>
      <td>${specialistName.replace(/(^|\s)\S/g, (match) => match.toUpperCase())}</td>
      <td>${new Date(appointment.date).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      })}</td>
      <td>${appointment.time}</td>
      <td><span class="status-pill status-${statusClass}">${appointment.status}</span></td>
    `;

    dom.appointmentTableBody.appendChild(row);
  });
}

renderStoredAppointments();
